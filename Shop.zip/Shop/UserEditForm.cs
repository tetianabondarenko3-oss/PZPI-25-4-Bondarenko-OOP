﻿namespace shop;

/// <summary>
/// Діалогове вікно для створення користувача програми.
/// </summary>
public sealed partial class UserEditForm : Form
{
    /// <summary>Користувач, створений у діалоговому вікні.</summary>
    public AppUser User { get; private set; } = new();

    /// <summary>Створює діалог користувача.</summary>
    public UserEditForm()
    {
        InitializeComponent();
        FormHelpers.ConfigureHotkeys(this, createButton, cancelUserButton);
        roleComboBox.DataSource = Enum.GetValues<UserRole>();
    }

    private void CreateButton_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(loginTextBox.Text) || string.IsNullOrWhiteSpace(passwordTextBox.Text))
        {
            MessageBox.Show("Логін і пароль обов'язкові.", "Користувачі", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        User = new AppUser
        {
            Login = loginTextBox.Text.Trim(),
            FullName = string.IsNullOrWhiteSpace(nameTextBox.Text) ? loginTextBox.Text.Trim() : nameTextBox.Text.Trim(),
            Password = passwordTextBox.Text,
            Role = roleComboBox.SelectedItem is UserRole role ? role : UserRole.Cashier
        };
        DialogResult = DialogResult.OK;
        Close();
    }

    private void CancelUserButton_Click(object? sender, EventArgs e) => Close();
}

