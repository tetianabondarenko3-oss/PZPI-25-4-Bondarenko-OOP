﻿namespace shop;

partial class MainForm
{
    private MenuStrip mainMenuStrip = null!;
    private Label summaryLabel = null!;
    private StatusStrip statusStrip = null!;
    private ToolStripStatusLabel userStatusLabel = null!;
    private ToolStripStatusLabel fileStatusLabel = null!;
    private ToolStripMenuItem productsMenuItem = null!;
    private ToolStripMenuItem supplyMenuItem = null!;
    private ToolStripMenuItem saleMenuItem = null!;
    private ToolStripMenuItem correctionsMenuItem = null!;
    private ToolStripMenuItem inventoryMenuItem = null!;
    private ToolStripMenuItem reportsMenuItem = null!;
    private ToolStripMenuItem returnsMenuItem = null!;
    private ToolStripMenuItem usersMenuItem = null!;
    private ToolStripMenuItem dataMenuItem = null!;
    private ToolStripMenuItem saveMenuItem = null!;
    private ToolStripMenuItem backupMenuItem = null!;
    private ToolStripMenuItem exitMenuItem = null!;

    private void InitializeComponent()
    {
        mainMenuStrip = new MenuStrip();
        summaryLabel = new Label();
        statusStrip = new StatusStrip();
        userStatusLabel = new ToolStripStatusLabel();
        fileStatusLabel = new ToolStripStatusLabel();
        productsMenuItem = new ToolStripMenuItem();
        supplyMenuItem = new ToolStripMenuItem();
        saleMenuItem = new ToolStripMenuItem();
        correctionsMenuItem = new ToolStripMenuItem();
        inventoryMenuItem = new ToolStripMenuItem();
        reportsMenuItem = new ToolStripMenuItem();
        returnsMenuItem = new ToolStripMenuItem();
        usersMenuItem = new ToolStripMenuItem();
        dataMenuItem = new ToolStripMenuItem();
        saveMenuItem = new ToolStripMenuItem();
        backupMenuItem = new ToolStripMenuItem();
        exitMenuItem = new ToolStripMenuItem();
        mainMenuStrip.SuspendLayout();
        statusStrip.SuspendLayout();
        SuspendLayout();

        productsMenuItem.Text = "Товари";
        productsMenuItem.Click += ProductsMenuItem_Click;
        supplyMenuItem.Text = "Надходження";
        supplyMenuItem.Click += SupplyMenuItem_Click;
        saleMenuItem.Text = "Продаж";
        saleMenuItem.Click += SaleMenuItem_Click;
        correctionsMenuItem.Text = "Уцінка і списання";
        correctionsMenuItem.Click += CorrectionsMenuItem_Click;
        inventoryMenuItem.Text = "Інвентаризація";
        inventoryMenuItem.Click += InventoryMenuItem_Click;
        reportsMenuItem.Text = "Звіти";
        reportsMenuItem.Click += ReportsMenuItem_Click;
        returnsMenuItem.Text = "Повернення";
        returnsMenuItem.Click += ReturnsMenuItem_Click;
        usersMenuItem.Text = "Користувачі";
        usersMenuItem.Click += UsersMenuItem_Click;

        saveMenuItem.Text = "Зберегти";
        saveMenuItem.Click += SaveMenuItem_Click;
        backupMenuItem.Text = "Резервна копія";
        backupMenuItem.Click += BackupMenuItem_Click;
        dataMenuItem.Text = "Дані";
        dataMenuItem.DropDownItems.Add(saveMenuItem);
        dataMenuItem.DropDownItems.Add(backupMenuItem);

        exitMenuItem.Text = "Вихід";
        exitMenuItem.Click += ExitMenuItem_Click;

        mainMenuStrip.Items.Add(productsMenuItem);
        mainMenuStrip.Items.Add(supplyMenuItem);
        mainMenuStrip.Items.Add(saleMenuItem);
        mainMenuStrip.Items.Add(correctionsMenuItem);
        mainMenuStrip.Items.Add(inventoryMenuItem);
        mainMenuStrip.Items.Add(reportsMenuItem);
        mainMenuStrip.Items.Add(returnsMenuItem);
        mainMenuStrip.Items.Add(usersMenuItem);
        mainMenuStrip.Items.Add(dataMenuItem);
        mainMenuStrip.Items.Add(exitMenuItem);
        mainMenuStrip.Location = new Point(0, 0);
        mainMenuStrip.Name = "mainMenuStrip";
        mainMenuStrip.Size = new Size(1180, 28);

        summaryLabel.Dock = DockStyle.Fill;
        summaryLabel.Font = new Font("Segoe UI", 13F);
        summaryLabel.Name = "summaryLabel";
        summaryLabel.TextAlign = ContentAlignment.MiddleCenter;

        statusStrip.Items.Add(userStatusLabel);
        statusStrip.Items.Add(fileStatusLabel);
        statusStrip.Location = new Point(0, 651);
        statusStrip.Name = "statusStrip";
        statusStrip.Size = new Size(1180, 26);

        AutoScaleDimensions = new SizeF(8F, 20F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1180, 677);
        Controls.Add(summaryLabel);
        Controls.Add(statusStrip);
        Controls.Add(mainMenuStrip);
        MainMenuStrip = mainMenuStrip;
        Name = "MainForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Магазин. Комп'ютер замість касового апарату";
        WindowState = FormWindowState.Maximized;
        mainMenuStrip.ResumeLayout(false);
        mainMenuStrip.PerformLayout();
        statusStrip.ResumeLayout(false);
        statusStrip.PerformLayout();
        ResumeLayout(false);
        PerformLayout();
    }
}

