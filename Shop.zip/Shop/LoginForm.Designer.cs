﻿namespace shop;

partial class LoginForm
{
    private TextBox loginTextBox = null!;
    private TextBox passwordTextBox = null!;
    private Button loginButton = null!;
    private Button cancelLoginButton = null!;
    private Label loginLabel = null!;
    private Label passwordLabel = null!;
    private Label hintLabel = null!;

    private void InitializeComponent()
    {
        loginTextBox = new TextBox();
        passwordTextBox = new TextBox();
        loginButton = new Button();
        cancelLoginButton = new Button();
        loginLabel = new Label();
        passwordLabel = new Label();
        hintLabel = new Label();
        SuspendLayout();

        loginLabel.AutoSize = true;
        loginLabel.Location = new Point(24, 28);
        loginLabel.Text = "Логін";

        loginTextBox.Location = new Point(120, 24);
        loginTextBox.Name = "loginTextBox";
        loginTextBox.Size = new Size(220, 27);
        loginTextBox.Text = "admin";

        passwordLabel.AutoSize = true;
        passwordLabel.Location = new Point(24, 68);
        passwordLabel.Text = "Пароль";

        passwordTextBox.Location = new Point(120, 64);
        passwordTextBox.Name = "passwordTextBox";
        passwordTextBox.PasswordChar = '*';
        passwordTextBox.Size = new Size(220, 27);
        passwordTextBox.Text = "admin";

        hintLabel.AutoSize = true;
        hintLabel.Location = new Point(24, 108);
        hintLabel.Text = "Початкові облікові записи: admin/admin, cashier/cashier";

        loginButton.Location = new Point(134, 145);
        loginButton.Name = "loginButton";
        loginButton.Size = new Size(100, 32);
        loginButton.Text = "Увійти";
        loginButton.UseVisualStyleBackColor = true;
        loginButton.Click += LoginButton_Click;

        cancelLoginButton.Location = new Point(240, 145);
        cancelLoginButton.Name = "cancelLoginButton";
        cancelLoginButton.Size = new Size(100, 32);
        cancelLoginButton.Text = "Вийти";
        cancelLoginButton.UseVisualStyleBackColor = true;
        cancelLoginButton.Click += CancelLoginButton_Click;

        AcceptButton = loginButton;
        CancelButton = cancelLoginButton;
        AutoScaleDimensions = new SizeF(8F, 20F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(380, 198);
        Controls.Add(hintLabel);
        Controls.Add(cancelLoginButton);
        Controls.Add(loginButton);
        Controls.Add(passwordTextBox);
        Controls.Add(passwordLabel);
        Controls.Add(loginTextBox);
        Controls.Add(loginLabel);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "LoginForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Вхід до програми";
        ResumeLayout(false);
        PerformLayout();
    }
}

